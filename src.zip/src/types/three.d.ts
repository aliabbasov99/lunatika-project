declare module 'three'
